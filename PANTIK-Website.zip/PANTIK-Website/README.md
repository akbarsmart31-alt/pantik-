# PANTIK — Website Arsip Digital

Website statis HTML, CSS, dan JavaScript. Tidak memerlukan instalasi Node.js.

## Menjalankan
Buka `index.html` di browser.

## Struktur
- `index.html` — struktur halaman
- `style.css` — desain dan responsif
- `script.js` — data edisi, daftar karya, pencarian, dan pembaca
- `assets/` — tempat menyimpan file PDF karya

## Menambahkan PDF karya
1. Salin PDF ke folder `assets/`.
2. Buka `script.js`.
3. Cari karya yang sesuai pada array `WORKS`.
4. Isi properti `file` dengan nama file PDF, contoh:
   `file: "think-is-art.pdf"`
5. Simpan perubahan.

## Menambahkan edisi baru
Tambahkan objek baru ke array `EDITIONS` di `script.js`, misalnya:
`{ id:"02", title:"Edisi 02", subtitle:"Deskripsi edisi.", status:"TERSEDIA", description:"Kumpulan karya edisi kedua." }`

Lalu tambahkan karya-karya edisi tersebut ke array `WORKS`, gunakan `edition:"02"`.
Untuk edisi yang belum terbit, gunakan status `"SEGERA"`.

## Publikasi
Unggah seluruh isi folder ini ke repository GitHub, lalu impor repository tersebut ke Vercel.
Untuk website HTML/CSS/JS statis, tidak perlu Build Command dan Output Directory khusus (gunakan root repository).

## Privasi penemuan
Meta robots `noindex, nofollow` sudah dipasang. Ini meminta mesin pencari tidak mengindeks website, tetapi bukan perlindungan akses atau kata sandi. Siapa pun yang memiliki URL tetap dapat membukanya.
