/*
  PANTIK — data arsip
  Untuk menambah edisi/karya, edit daftar EDITIONS dan WORKS di bawah.
  Letakkan PDF di folder assets/, lalu isi file dengan nama file PDF.
*/
const EDITIONS = [
  { id:"01", title:"Edisi 01", subtitle:"Catatan, gagasan, dan hal-hal yang tertinggal.", status:"TERSEDIA", description:"Kumpulan karya dalam edisi pertama PANTIK." },
  { id:"02", title:"Edisi 02", subtitle:"Ruang untuk kumpulan karya berikutnya.", status:"SEGERA", description:"Edisi berikutnya akan ditambahkan di sini." },
  { id:"03", title:"Edisi 03", subtitle:"Arsip yang terus bertumbuh.", status:"SEGERA", description:"Ruang untuk edisi mendatang." }
];

const WORKS = [
  { id:"01", title:"Think is Art", edition:"01", type:"Tulisan", description:"Sebuah catatan tentang pikiran dan proses kreatif.", file:"" },
  { id:"02", title:"Sekarang Agak Serius", edition:"01", type:"Tulisan", description:"Catatan personal.", file:"" },
  { id:"03", title:"Negara di Ujung Tagihan", edition:"01", type:"Tulisan", description:"Catatan tentang kehidupan dan keadaan.", file:"" },
  { id:"04", title:"Tagihan", edition:"01", type:"Tulisan", description:"Sebuah karya dari arsip PANTIK.", file:"" },
  { id:"05", title:"Kanopi yang Retak", edition:"01", type:"Tulisan", description:"Sebuah karya dari arsip PANTIK.", file:"" },
  { id:"06", title:"Doa Semester Tiga", edition:"01", type:"Tulisan", description:"Sebuah karya dari arsip PANTIK.", file:"" },
  { id:"07", title:"Cinta dalam Cicilan Waktu", edition:"01", type:"Tulisan", description:"Sebuah karya dari arsip PANTIK.", file:"" },
  { id:"08", title:"Terakhir Dilihat", edition:"01", type:"Tulisan", description:"Sebuah karya dari arsip PANTIK.", file:"" },
  { id:"09", title:"Ini Arahnya ke Mana?", edition:"01", type:"Tulisan", description:"Sebuah karya dari arsip PANTIK.", file:"" }
];

const editionList = document.querySelector("#edition-list");
const workList = document.querySelector("#work-list");
const search = document.querySelector("#search");
const filters = document.querySelector("#filters");
const emptyState = document.querySelector("#empty-state");
const reader = document.querySelector("#reader");
let activeEdition = "SEMUA";

function renderEditions(){
  editionList.innerHTML = EDITIONS.map((e,i)=>`
    <article class="edition-card">
      <div class="edition-meta"><span>PANTIK / ${e.id}</span><span>${e.status}</span></div>
      <div class="edition-cover" aria-hidden="true">${i===0?"P.":`0${i+1}`}</div>
      <div><h3>${e.title}</h3><p>${e.subtitle}</p><button data-edition="${e.id}">${e.status==="TERSEDIA"?"LIHAT KARYA ↗":"SEGERA HADIR ↗"}</button></div>
    </article>`).join("");
  editionList.querySelectorAll("button").forEach(btn=>btn.addEventListener("click",()=>{
    const ed=EDITIONS.find(e=>e.id===btn.dataset.edition);
    if(ed?.status==="TERSEDIA"){activeEdition=ed.id;renderFilters();renderWorks();document.querySelector("#arsip").scrollIntoView({behavior:"smooth"});}
    else openReader(ed.title,ed.description,`<p>Edisi ini belum diterbitkan. Silakan kembali lagi nanti.</p>`,ed.title.toUpperCase());
  }));
}
function renderFilters(){
  const values=["SEMUA",...EDITIONS.filter(e=>e.status==="TERSEDIA").map(e=>e.id)];
  filters.innerHTML=values.map(v=>`<button class="${activeEdition===v?"active":""}" data-filter="${v}">${v==="SEMUA"?"SEMUA EDISI":"EDISI "+v}</button>`).join("");
  filters.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{activeEdition=b.dataset.filter;renderFilters();renderWorks();}));
}
function renderWorks(){
  const q=search.value.trim().toLowerCase();
  const shown=WORKS.filter(w=>(activeEdition==="SEMUA"||w.edition===activeEdition)&&(`${w.title} ${w.description} ${w.type}`).toLowerCase().includes(q));
  workList.innerHTML=shown.map(w=>`<article class="work-item"><span class="work-number">${w.id.padStart(2,"0")}</span><div><h3>${w.title}</h3><p>${w.type} · ${w.description}</p></div><span class="work-edition">EDISI ${w.edition}</span><button class="work-open" data-work="${w.id}" aria-label="Buka ${w.title}">↗</button></article>`).join("");
  emptyState.hidden=shown.length!==0;
  workList.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>openWork(b.dataset.work)));
}
function openReader(title,description,content,editionLabel="PANTIK / EDISI 01"){
  document.querySelector("#reader-title").textContent=title;
  document.querySelector("#reader-description").textContent=description||"";
  document.querySelector("#reader-content").innerHTML=content;
  document.querySelector("#reader-edition").textContent=editionLabel;
  reader.showModal();
}
function openWork(id){
  const w=WORKS.find(x=>x.id===id); if(!w)return;
  const content=w.file
    ? `<p>Karya ini tersedia untuk dibaca.</p><p><a href="assets/${w.file}" target="_blank" rel="noopener">Buka dokumen PDF ↗</a></p>`
    : `<p>Dokumen karya ini belum dimasukkan ke paket website. Setelah file PDF tersedia, letakkan di folder <strong>assets</strong> dan isi nama file pada properti <code>file</code> karya ini di <code>script.js</code>.</p>`;
  openReader(w.title,w.description,content,`PANTIK / EDISI ${w.edition}`);
}
search.addEventListener("input",renderWorks);
document.querySelector(".reader-close").addEventListener("click",()=>reader.close());
document.querySelector(".menu-toggle").addEventListener("click",e=>{
  const nav=document.querySelector(".site-header nav");
  nav.classList.toggle("open");e.currentTarget.setAttribute("aria-expanded",nav.classList.contains("open"));
});
document.querySelectorAll(".site-header nav a").forEach(a=>a.addEventListener("click",()=>document.querySelector(".site-header nav").classList.remove("open")));
renderEditions();renderFilters();renderWorks();
